package toni.sodiumleafculling.celeritasleafculling;

/**
 * Tags storage class, you can change at will
 */
public class Reference {
    private Reference() {}

    public static final String MOD_ID = "celeritasleafculling";
    public static final String MOD_NAME = "Celeritas Leaf Culling";
    public static final String VERSION = "1.0.0";

}